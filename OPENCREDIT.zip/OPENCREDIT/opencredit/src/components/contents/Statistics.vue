<template>
    <div class="content">
        <img id="maintitle" src="src/assets/1.png" alt="1.png">
    </div>
</template>

<script>
export default {
    
}
</script>

<style scoped>
    .content {
        width: 85vw;
        min-height: 500px;
        background-color: rgb(187, 218, 236);
    }
    p {
        margin-top: 0px;
        margin-bottom: 0px;
    }
</style>