<template>
    <div class="wrapper">
        <img id="maintitle" src="src/assets/maintitle.png" alt="maintitle.png">
        <div>
            <p id="title"><b>Opening Credit</b></p>
            <p id="subtitle"><b>대학생을 위한 신용 예측</b></p>
        </div>
          <img id="maintitle" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQDxAQDxAPFRAQEBAVEBAPEA8QFRAVFhUXFhUVFhUYHSggGBolGxUVIjEhJSktLi4uGB8zODMtNygtLisBCgoKDg0OFxAQGi0lHyYtLS8tLS0tLSstLS0tLS0rLS0tLS0tLS0tLS0tLS0tKystLS0tLS0tLS0tLS0tLS0tLf/AABEIAKsBJwMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAAAQIDBAUGB//EADkQAAIBAgQDBgMHBAEFAAAAAAECAAMRBBIhMQVBURMiYXGBkQYywSNCUmKhsdEUguHwcjNDY5Lx/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAECAwQF/8QAJREBAQACAwEAAgEEAwAAAAAAAAECEQMhMRIEQVEFIkJSE4GR/9oADAMBAAIRAxEAPwD1mEISmZIQhGBEixlWoFUsxsFBJPgIE5n4yxnyUAfzv+yj9z7TnsBw2riHyUUzMBc6gADqSY/G1zVqPUbdze3Qch7WknCse+GqiqlrgMLHY3H82PpO2Y3HDU9cGWUyz3fFLHYU0qj02KlkNmKEkX5i/gdPSP4bjTQqZwARYhlPMfSNylm5lmPmWJP6mW64AoJk7MqO6+ZLVBUN2JB3tYAb8touTCZY/OU3sYWy/WPWnQYDjNCrYZij8hUNgPI7GbVhfUm+mVhoLdOk88rYQKikuM5UMaZVhYH5ddiSLHyIklLH4miMoeoqsNAw5HmL/SeRy/0mXviv/Vejx/1Czrkn/i18YY01Kwp3utIW6XY7/QTnysna5NzudyecYRPV4OGcXHMJ+nncvJeTO5VCRGlZMVjSs00hCVjSsmIjSsQQlYwrJysaVgEBWMKywVjSsQNw2Cq1WK0qdR2AuRTRnIHUgCRVqLIxV1ZWG6uCpHmDOh4lVelg8HTpErTrU3q1WQle1qZ2UqxG+UKot4x/D0erh6uIxSVMRTw4FKhTJqXzOQTd172VVF97aiRv9r+f05iE6DF/DjNVVcOCofDLiCmIdUNEMSuRnNhe9rXtcETHxuCq0WyVUZG3swtcdQdiPERyylcbFrh/HMRRsFfMv4KneHpzHpOm4f8AFNGpYVL02/Nqv/ty9Zw8IagmVj1VGBAIIIOxBuD6xZ5ngeI1qBvScjqu6nzU6TpeH/FqnSumU/jS5X1G4/WLS5lHTQkWHxCVFzU2Vl6qQZLEosIkIgWESLAC8WJCAdBCEJzuwkDCEYEwvirF5aYpA61Pm/4j+T+03ZwvFcV21Z35Xsv/ABG38+s24cfrJhzZax0zyIhEltG2nZpxI9tRuNiOUe1csymqWdRuM1ieutt9Bqb7QIjSIrDl0toy1SlMs5RSzFqmRXIyi1NTrzFh57RtS5Bw6LVBZgSlYr9nlBJAJtbqTZdBKhEko1yhJsDdSpDXPdO4B3GmnrIuK5n/ACXG4RVTNkqU2zABGIZX0uWVtDbbqNRrKBWWKoUklRYcgTmt4XtGFY5L+05Wb6QERCJMVklXBuqhyBlIB0IJF9sw3F9xeMtKZWNKyYiNIhokNo0rJisaVi0aErGlZMRGkRBPheI1KaGmMj0mJJpVUWol7WzAHVT4giX+E8Yy1cCuY0qOHe9Rgzd8s16jNbkQALdJkFY0iTcZVTKx0L1FpYPPXpVai4+ozVai1HU00RrUk7Q3Ba4Y5TyteVKDJh8K1YotQ16hpYVMSoqBaKHNUbLsLkquh0N7TOw2Mq0swpVGUOCHUHRgRbUbGXqmPw9ZKK4inWU0KYpocO6gMoJOqODY3JuQdeki46X9bMxHBxX/AKR8MgT+saonZFmK03pkByGOvZ2IOtyNd5lYrhtWmi1GQ9k3yVV71NtSNGGnLY2PhOlbiajD1KyKKYVP6XB0g2Zqav3q1VjzYgjXq0rU8U+BwdMU2y1sW3avoCBRS601KkWIY5j4gCKWizFzEJrYbhj4jtK7NRo0Q/eqP3EDHXIiqCSfACV+IcNNIK4qUqlNyQtSk19RYkMpAZTqNxzl7/SPm+quHxD02zU2ZW6qSPfrOh4f8WuLCuoYfjSyt6jY/pOahApXpWB4lRrj7JwTzXZh/adZbnlasQbgkEbEaETb4f8AE9anYVPtF/Now/u5+snS5k7mLMzhvHKFewVsrn7j6H05H0mkIlQsIQiN0EIQnO7CQjDVAYJ95lZgPAWBPuRHwDM+IMV2dEgfNU7o8vvH209ZyBE1OOYntKxt8qd1fqff9pnET0OLH5xcPLl9ZI7RpEltJFodzOWA72UXBN9Lnbpp7zS3TLW1UiNIlipRKgEjRhcG4N/aRkQKzSIiNIkpEQiARERpEltEIi0DKVNSbM2Ua96xaxtpcDleT8QKuVPcNQA9o9PMVsLBdOVlHLkRzvISItKoyHMhIPUaekmzvapdTSbiaKMoRaZpkfZ1FBDMF0OYX3v1Er18IAoem4dGYqNCrXsDYr6jYmWsNjCGZmLBimVHphVNK5uSqiw69PmMdTQ1Wdnd3WmLjswqszEgXAI30uTv3RI7i+qyWWxIO43HSMImjjsRnCLdmyZvtHADEG1l3JsLdeZlIrKnbOzVRERpWSlYhEZISI0iTERpEWjQkRpWTFY0rEEJWSYzEPVbNUbM2VVBsBZVAVQANALCKRGFYtBrnDPicFh0oAu+HeuatFdXOdgVqBd2FtNNrSHgfATVzVaqOaVPN9ktlqYl13pUwddPvEageMzdQbjQjYjQiPxOIqVAgd2Iprlp3PyC99PXnI+b+l7ntjY4zw018fQoqiUmehhzVCJkWl3M9Rivgp59JkY3hYWmK1CqKtFqnZ3yFHRyLqrIb7gGxBN7ek26/HkzYrEoPt6wpUqaVUDhaQRRULX0ObLlt0MvVWFOsx7OnTw2Cp0cS1KmhAbE1KS9mrG9z3206AGRuxprG7cLUplSVYEMDYqwIIPiDtGzpcNXfF0MX/UnOaFE1adZ7F6bZgAmbcq1yMp6aTnCsuVlZo2eifD+Karhqbvq2qk9cpIv+k89VCSABckgAdSZ6TwzCCjRSmPurqerHVj7kwyPBbhCEho6CQmt9rkB2TMwseZsuvLZpNMu2XH7f9TDb5uaPqMvkw1/zOd2H3vjN/kw22v3qnt9yS8UxPZ0mbmdF8zGioP6srlNzh1Oa+hCuRa3928zPiOqS6pyVb+p/wDk04sfrKRHJl84sQiJaSWiWnouFERFDHblpccuseRGkQ0SejiAGJsBcBdswCAWIseZsPcysqF25XNydgABqTpsAIpEVGINx4j0Isf0k/OvD3v0x6J3GovYEA6m1+eu0iIlylX0CnRb62AuAT3zfe5GnkJIyI922VQF7oC75iDryAHmfWL616PmXxm2iES3VwjKAeoU253a9h4nTlIGQg2III3B0tKllTZYhtEIkpEbaBI7RBcEEEgjYjQiSERCItBE9ySSSSdyTcn1jCJcTClkLAjewXW7dbepUeshqUypIIsRuDEeqhWkWIA3JAF9N/GT8Rw6IxVRUBGnfsQ4/GpFrA9NfOFFwpN1VgRYhr+B0I1B03k1N87qbovZhezSoWKkA3sW0HU62Em72qa0pYnCPTNnUjz/AGuOfhK5E1noq7s6sgVQjOXJqIajalQQDfW+9/lOttZDi0plkH2aMb9oaZLoNdLAX5cgecUyFxZxWNKy3icKUy6qQwurKbhhcjzGoOhlciUnSErEKyYrGkRaJCRGlZMVjSItGhIlvB8RemrJZHpvlL06q51YqLKb/MpAOhBEgIjSsVmzl0tY3ijPS7FKdKlSLBnSkG+0YbF2Ykm3IXtMwrJysaVi1oW2+tT4UwGev2hHdpC/mx+X6n0E7WZ/A8F2NBVPzN3n8zy9BaaEzt7aYzUEIQiU6CY/xD9n2OKCljh3OYLbVHFmufabEjr0g6MjbMpB8iLTndjH4viDSrYXEC3ZNenUbkFexVr9Ba/pLHGeHmqAyfMotb8Q/mZeEwzIHwOLBai2tGvew6hcx2Omg8+U0sFiuxanha18+W1KoActRRoL/hew1H66yscrjdxOWMymq5+pTZTZgQehFo2dnWoK4s6gjx+nSZOL4EN6TW/K30M68PyJfenNlw2eMG0QiT4jDPTNnUjx5HyMinRLL4ys0YREIj7RCIEjtEtJLRCIEkp4k3u927pA1ta5u2u+tyCfGQ00DML6C9z4Aan9IERCIvnXh7t9SVsOt2yEhVUN9pobG1hcc9RvaVmQjcEaA69DsZY7Q2sdiQT1PmY7FYgudrAW8bmwHtpYCTNwWSqZEFpliANyQB5mPIkuFdVYls3ysFKgEqSLXsd+cq+Jk7D0jT7yVFZQwBKkjXUjunW2h1EP6u4VGUWViWJF77XFvQDyAgwvkp09bNvYrmY2AsDyAsPUxcZXzAKWDsCSa1t+ihj3mG5ufC0z/jbTzekVXDghSpGZt0W9l5nU8gCvPmekrVKJG405HkfIywcOwsNmewCXOY32uOQ23jzUZAyMGVgABcEZRe50PXr+kadKtKsyXAtlO6sAynoSDz133k2DrhVYA5GYjvFQ6lQPkI10JN+ewj6lGnlLLmsMqja5OpLMOQ2Fv3tKZEWpRu4mVnLG7EbWAACgDkABoBv7mRFZMREIj1pNu0BWNKzQwNLvCoUZkpkFwtr21tp00k1ag9XECmzl+ZfKA1rZ2uObAX0udRYRW9nMdxjkRpWXXoBny0s2t9KmRCPC97H9PKQ1aLKSrKQRuGBBHvArFcrGlZMRGkQ0SEiXuB4Ptay3HdTvN6bD3t+sqlZ1Xw9hOzo5j81TX0+6Pr6ycuovGbrUhCLaYtSQiwgbfhCE53WhxeFSqhp1FDIdwb+4I2MKWHVUCalQLWcl9OlzvJoQBqqAAAAABYAchFhCMKPHHK4eqR0A9yB9Zxy1jz1nZ8XplqFUDfIT7a/ScSUO/LqI5nljeqPiZTtZWoDHSlJFqkTow/J/2YZ/j/6rMQiMSqD4SSdOOUy8c+WNx9MIiESSJaUlHaNIkpEaRAkdolpIREtAI7RablbkWvybcr4jx8eUdaNtFYEuDohs5IztplTOVLE6lupsAfUiOAapYBfs6N+7VqWvmOxOlulh0lciSU6uVSpVWUm5U6agWBBGoOp95Fx/aplDMZSVSAAQxHfQkNkNyLX8hfXqJWIkuUDYW8IhEqTpF9RERpElIiEQJGCQbgkEcwbER9J1AIdL3N8ysVdfI6j3EQiJaKzZyri2qh6jKr1Hc3TtGUogG6m/ePLW+20iRWez5aZVR2dOnVc94AahTpcjMDy+YWlYrJRXOTIQrKL5Qw+QncgixvIuK/v+UGNRA5FP5dPvBwDbvANzANx6SuRJyI0rKniLezsBhe1qqnIm7eQ3nZAW0Eyvh3CZUNQ7vovkP8/tNe0wzy3WuE6NixbQtIWSEdEgG7CLEmDrEIQgCQhCAE5bivCnpMXpDNSJuVGpT06TqYQEunAdqh3BB8IxivK/tO4xHD6L/PTQnrax9xrI6fCcOuopJ63b94aV9OSwWCqVjamunNjsPWdRR4NSWmEIuRu+xJ/jwmgoAFgAANgNLTM4zxPshlSxqEb7hB1845fnuJv93TN4hw4UtRUS3IMQrf5lAiXuFcFfEntKrMEP3jqz+V+XjOhPCKCU8oTTxZm166nT0m+H5N/yY5fjz9OQiWm1ieCc6bf2t/Myq2HdDZ1I89vedWPJjl45ssLPUJES0fEIlpR2iESQiIRAkdolpJaNtAIyIhEkImtg+HoaYzjVtb7EdJOWUx9PHG5MMiIRNbE8JYaocw6HQzOemQbEEHoRaEyl8K42IbRpElIjSI0oyI0iSkRCIBCRH0KBdlUbsbfyYpE1+AYXVqhG3dX6n/esjO6m1Yzd01qdMKoUbKAB6R1o60Scro0S0LRYQBLQi2hANuJFhMHUSEIQAiRYhgBCEIwSEIQJFXqZVJ58vOYpwgqOC3UX6sTyl3G17vl6aesfhE7y+DADz5n6SauRtKoAAGwGgHKRYvb1k8rYltbdIQ74gnJ/EOLLVioJy09B58z9PSdZOb4lwwlndDfvnMOmv+Y6jGMdK556yZKgOx9I2tg3X5lPsZXKTXD8jLH3tGfBjfOl2EqrVYePnJkrA+HnOvDmxyc2fDlieRG2j4TVkdhKGdwvLc+QnQWmbwp0W9zZjtfp5zTnPy3db8c1DYyrSVxZgCPGSxLTJoycRwjnTP8Aa38zMrYdkNmUj9j6zqLRGUEWIBHQ6zTHls9ZZcUvjkyIhE2eI4Gmql1uDp3dwT9JkkTfHKZTbHLHV0jVCSANybDznV4eiERUH3R7nmfeZHBMNmcudk28zN20w5su9NOPHrZsSPtEtMWhtoR1oWgDYsW0WAa0IQmLpJCLEgBCEIAkIsSAEIQjDn2qXrsPwlz7X/xNbBLZlHSFfBIzZ7WexFxzBFrHrHUKBUg5ibbA/wC6ydK+o0KtS3nKpimJKTbskxeJu1Cqati1KpYVAPusNL+om1EdAwIYAg7gi4MCl0y8NiFcfZsrD8JNiI2vgkfelY9QVEgxfw4pN6T5fytqB5HcTExAqIxTtCbaXV2tJaS7XMdw5aYuXUdFJ7x9JBwrB9tVA+4tix6jp6x+B4Sz2Z7gHYD5m8fAeM2qWCSkQyKBbndi3vAVZxOBp1PmXX8Q0M5moyhiAbi5sTzHWdXir9m9t8jW87Ti0Ogm05ssfGP/ABY5erMmoYp02OnQ6iUgbR4q9Zvj+Rhl1kxy4Mse42qHElOjDKeu4l1SCLggjqNZzYMkpVmU3Ukf70l3jl7iJyWeugiWlChxPk49V/iW2xK5C4IIA/XkJlcLGkylZXF612CjZd/MzPtJWJJJO5NzLXCsPnqAnZNT58h/vSdHWGLnv92TWwOH7Omq8928zJ7R1oWnFbu7dEmjbRLR1oWgZsLR1oQBtoRYQJqQhCZOgRIsIAkIQgBEiwgCQhCAJCLCMiQhCAJEixrtYE9ATAKnEKptlXc7noJmYbAC4LAE/dBGg/Mf4llXzEnfn59BNHDYNjvpfcyWkmkCJbbc79TJjhWIBOig3PU9BNCnRVdh6yCvUudNhCC3SC05HFUP6esVcE021BHTqPEdJ2ErY7BpWXK48iN1PUSr2zxuqwTwvMA1Jgyna2hHpKVfCsp1Es1MBicOxamSV6prf/ksBxxrWqU0brfT9DIablZ+0lpsSQLXJIA8zJHxHam1Kjr0BLfpbSavCOElCKlW2YfKo+74nxl4ZZY3pGeONnahiMI9P5l06jUe8hnWkSjiOF021HdP5dvadmPPP8nJlxfwwJvcLw+SmL7tqfp/vjG0OEopuSWtytYReIcWo0NHa7namneY9O6NpHLyzKah4Ya7q5aUqGKNWqclxTpFg7FdKrbWQ9Ab3PW0hqUqmKUZg9GibEre1SoOht8i+G/lNFVVFAACqo05BQPpMWpTG02DAMDcEAgjmDqDM6pVGK7lJj2II7Wqv/c/8aH9z6TUAA0G3IDlAtG2haOtC0AbCOtCAaEIkJm2LCJCAEIQgBCEIARIsSAEIQgCQixIyEZWp5lZeoIj4QClwnDFMwfcNvyItoR+s1ywAlQQJi0r6Pq1b6Db95FaLCNNNMIsSBEjHpqd1U+YBkkSMjVUAWAAHQaQiyJzFacmz7RJHeTgd2/O8NncNM/HcOFYjNVrBR9ym4QHzsLn3j8Lw+lRuaVNVLfM2pJ8ydTLZiSkKDU8Vmaz4cJbu/Z1CQfEZpVHBncg4nEPVW2tJR2SHpcKdZswgEVGiqKFRQqqLBQLAR9o6JAG2i2iwgRtosWJAP/Z" alt="maintitle.png">
    </div>
</template>

<script>
import GbButton from './../bxuip/gb-button.vue'
import { EventBus } from './../event-bus.js'

export default {
    components: {
        GbButton
    },
    data: function() {
        return {
            
        }
    },
    created() {
        
    }
}
</script>

<style scoped>
    @import url('https://fonts.googleapis.com/css?family=Lilita+One&display=swap');
    @font-face {
        font-family: 'BBTreeGR';
        src: url('https://cdn.jsdelivr.net/gh/projectnoonnu/noonfonts_nine_@1.1/BBTreeGR.woff') format('woff');
        font-weight: normal;
        font-style: normal; 
    }

    .wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
    }
    p {
        margin-top: 0px;
        margin-bottom: 0px;
    }
    #maintitle {
        width: 30%;
        margin: 100px 50px 100px 50px;
    }
    #title {
        font-family: 'Lilita One', cursive;
        font-size: 65px;
        margin-left: 50px;
        margin-right: 50px;
        color: #6495ED;
    }
    #subtitle {
        font-family: 'BBTreeGR';
        font-size: 30px;
        margin: 20px 50px 50px 50px;
    }

    /* Tablet */
    @media screen and (max-width: 1099px) {
        .wrapper {
            display: block;
            text-align: center;
            margin: 0 auto;
        }
        #maintitle {
            margin-bottom: 50px;
        }
        #title {
            font-family: 'Lilita One', cursive;
            font-size: 45px;
            margin-left: 50px;
            margin-right: 50px;
            color: green;
        }
        #subtitle {
            font-family: 'BBTreeGR';
            font-size: 25px;
            margin-top: 20px;
            margin-left: 50px;
            margin-right: 50px;
        }
    }

    /* Mobile */
    @media screen and (max-width: 499px) {
        #maintitle {
            width: 50%;
            margin: 50px 50px 20px 50px;
        }
        #subtitle {
            font-family: 'BBTreeGR';
            font-size: 15px;
            margin-top: 20px;
            margin-left: 50px;
            margin-right: 50px;
        }
    }
</style>