<template>
    <div class="content">
        <h1>- 느낀점</h1>
        <br></br>
        <div>
            <p> 짧은 시간 안에 기능 들을 전부 구현하는데 있어서 필요하다고 생각한 부분들이 있었습니다.</p>
            <br></br>
              <p> 1. API 서비스를 제공 하면 좋을 것 같습니다.  다른 기업들의 경우 100 call 당 10만원 상당의 비싼 가격으로 형성 되어 있습니다.</p>
            <br></br>
              <p> 2. 다양한 고객들을 대상으로 하는 종합신용정보집중기관으로서 챗봇을 두어 더욱 다양한 의견에 대응 하면 좋을 것 같습니다.</p>
               <br></br>
              <p> 3. 나와 비슷한 유형의 패턴을 지닌 사람들의 결과를 통계적으로 제시하면 좋을 것 같습니다.</p>
        </div>

    </div>
</template>

<script>
export default {
    
}
</script>

<style scoped>
    .content {
        width: 85vw;
        min-height: 500px;
        background-color: rgb(187, 218, 236);
    }
    p {
        margin-top: 0px;
        margin-bottom: 0px;
    }
</style>