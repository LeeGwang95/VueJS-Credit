# OpeningCredit

대학생을 위한 모의 신용등급 조회/관리 서비스 (UI만 구현)

<img src="./temp/screenshot01.png" width="50%" height="50%">
<img src="./temp/screenshot02.png" width="50%" height="50%">

## 😎 author

[youseokhwan](https://github.com/youseokhwan)

## 💻 development environment

- MacBook Pro 2017(Catalina 10.15.2) / Visual Studio Code 1.41.1

## 📀 software requirements

- Google Chrome

## 😥 issues

- 이미지 파일을 github 링크로 연결하여 속도가 느리거나 로드되지 않을 수 있음
- UI만 구현된 상태(세부적인 모의 신용등급 계산 과정은 미구현)

## 📋 notes

- 19년 2학기 취업브리지 강의 기말 프로젝트
- 반응형 웹으로 제작
